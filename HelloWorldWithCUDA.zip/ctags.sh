#!/bin/bash
ctags -R --c++-kinds=+p --fields=+iaS --extra=+q --exclude="backup" --exclude="doc"
