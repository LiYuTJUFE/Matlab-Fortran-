Project name:  HelloWorld
Author  name:  liyu@tjufe.edu.cn

1. What is HelloWorld?
   通过简单的三个不同类型的程序演示如何进行混合编程。
   具体如下：主函数分别用Fortran, C, C++编写，并用它们默认的编译器链接，
             四个主函数都调用三个同样的子函数，这三个子函数也是由上述
	     三种语言分别编译而成的。
	     另外，给出Matlab如何调用Fortran, C, C++的例子。
	     以及Fortran, C, C++调用CUDA程序
   希望通过这个例子，让大家熟悉这个开发环境以及初步了解如何进行混合编程。
   另外, 以一个例子让大家了解MPI以及MPI+OpenMP

2. Quick Start
   1. cd Main/
   2. make lib
   3. make exe
   4. make run-hello_F
   5. make run-hello_C
   6. make run-hello_CPP
   7. make run-hello_OMP
   8. make clean

   1. make -f Makefile.MPI lib
   2. make -f Makefile.MPI exe
   3. make -f Makefile.MPI run-hello_MPI
   4. make -f Makefile.MPI clean
