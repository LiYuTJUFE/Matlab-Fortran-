/**
 *       @file  hi.c
 *      @brief  
 *
 *   @internal
 *     Created  28/12/2020
 *     Company  liyu@tjufe.edu.cn
 *
 * =====================================================================================
 */
#include <stdio.h>
#include "hello.h"

   int
hi_( void )
{
   printf ( "This is C--int hi_().\n" );
   printf ( "Hi, hello world!\n" );
   return 0;
}		/* -----  end of function hi_ ----- */
