/**
 *       @file  hw_C.c
 *      @brief  
 *
 *   @internal
 *     Created  28/12/2020
 *     Company  liyu@tjufe.edu.cn
 *
 * =====================================================================================
 */
#include <stdio.h>
#include "hello.h"

int main(int argc,  char *argv[]) 
{
   int ierr = 0; 
   double tol = 0.01;
   double r = 0.5;
   printf ( "This is C--int main().\n" );
   ierr = hi_();
   ierr = whoami_();
   cpi_(&tol);
   printf ( "The area of a disk r = %f is %f \n", r, diskarea_(&r) );
   printf ( "\n" );
   /* calling CUDA */
   PrintDeviceInfo();
   SayHello();
   return 0;
}
