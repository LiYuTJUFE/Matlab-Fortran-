/**
 *       @file  hw_OMP.c
 *      @brief  
 *
 *   @internal
 *     Created  28/12/2020
 *     Company  liyu@tjufe.edu.cn
 *
 * =====================================================================================
 */
#include	<stdio.h>
#include	<omp.h>
#include	"hello.h"

int main(int argc, char *argv[]) {
   int i;
   printf ("This is C--int main() for OpenMP.\n" );
   printf ("Hello World! Num of procs : %d\n",omp_get_num_procs());
   printf ("Hello World! Num of thread: %d\n",omp_get_num_threads());
   printf ("Hello World! Master thread: %d\n",omp_get_thread_num());
   i = 5;
   printf ("Before omp parallel, master thread: %d, i = %d\n",omp_get_thread_num(),i);
#pragma omp parallel private(i)
   {
      printf ("[%d] In omp parallel, i = %d\n",omp_get_thread_num(),i);
      double tol=0.01, r = 0.5;
      i = omp_get_thread_num();
      if (i==0)
	 hi_();
      if (i==1)
	 whoami_();
      if (i==2)
	 cpi_(&tol);
#pragma omp master
      printf ("[%d] In omp parallel, master thread, i = %d\n",omp_get_thread_num(),i);
#pragma omp master
      printf ("[%d] The area of a disk r = %f is %f \n",omp_get_thread_num(),r,diskarea_(&r));
      i++;
   }
   printf ("[%d] After omp parallel, master thread, i = %d\n",omp_get_thread_num(),i);

   int sum = 0;
#pragma omp parallel for private(i) reduction(+:sum)
   for (i = 1; i <= 100; ++i) {
      sum += i;
      printf ("[%d] In omp parallel, master thread, i = %d\n",omp_get_thread_num(),i);
   }
   printf ("Sum from 1 to 100: %d\n",sum);
   return 0;
}
