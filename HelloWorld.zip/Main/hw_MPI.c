/**
 *       @file  hw_MPI.c
 *      @brief  
 *
 *   @internal
 *     Created  28/12/2020
 *     Company  liyu@tjufe.edu.cn
 *
 * =====================================================================================
 */
#include	<stdio.h>
#include	<mpi.h>

#if USING_OMP
#ifndef OMP_NUM_THREADS
#define OMP_NUM_THREADS 4
#endif
#include	<omp.h>
#endif

int GetLocalRange(int *start,  int *end,  int nglobal)
{
   int nprocs, rank, nlocal, surplus;
   MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
   MPI_Comm_rank(MPI_COMM_WORLD, &rank);
   nlocal = nglobal/nprocs;
   *start  = nlocal*rank;
   surplus = nglobal-nlocal*nprocs;
   if (rank < surplus) {
      nlocal++;
      *start += rank;
   }
   else {
      *start += surplus;
   }
   *end = *start+nlocal;
   return nlocal;
}



int main(int argc, char *argv[]) {
   int nprocs,rank;
   MPI_Init(&argc,&argv);
   MPI_Comm_size(MPI_COMM_WORLD,&nprocs);
   MPI_Comm_rank(MPI_COMM_WORLD,&rank);
   printf ("[%d/%d] This is C--int main() for MPI.\n",rank,nprocs);
   printf ("[%d/%d] Hello World! For MPI, this is %d proc and num of procs %d\n",
	 rank,nprocs,rank,nprocs);
#if USING_OMP
   printf ("[%d/%d] Hello World! For OpenMP, this is %d thread and num of threads %d with num of procs %d\n",
	 rank,nprocs,omp_get_thread_num(),omp_get_num_threads(),omp_get_num_procs());
#endif
   MPI_Barrier(MPI_COMM_WORLD);
   int i, sum, start, end;
   int nlocal, nglobal = 100;
   nlocal = GetLocalRange(&start,&end,nglobal);
   /* start from 1 */
   start += 1;
   printf ("[%d/%d] nlocal = %d, nglobal = %d, start = %d, end = %d\n",
	 rank,nprocs,nlocal,nglobal,start,end);
   MPI_Barrier(MPI_COMM_WORLD);
   sum = 0;
#if USING_OMP
#pragma omp parallel for reduction(+:sum) num_threads(OMP_NUM_THREADS)
#endif
   for (i = start; i <= end; ++i) {
      sum += i;
#if USING_OMP
      printf("[%d/%d](%d/%d) in omp parallel for, i = %d, sum = %d\n",
	    rank,nprocs,omp_get_thread_num(),omp_get_num_threads(),
	    i,sum);
#endif
   }
   MPI_Barrier(MPI_COMM_WORLD);
   printf("[%d/%d] before Allreduce, sum = %d\n",
	 rank,nprocs,sum);
   MPI_Allreduce(MPI_IN_PLACE,&sum,1,MPI_INT,MPI_SUM,MPI_COMM_WORLD);
   printf("[%d/%d] after  Allreduce, sum = %d\n",
	 rank,nprocs,sum);
   MPI_Finalize();
   return 0;
}
