/**
 *       @file  hw_Cpp.cpp
 *      @brief  
 *
 *   @internal
 *     Created  28/12/2020
 *     Company  liyu@tjufe.edu.cn
 *
 * =====================================================================================
 */
#include <iostream>
#include "hello.h"

int main(int argc,  char *argv[]) 
{
   int ierr = 0; 
   double tol = 0.01;
   double r = 0.5;
   std::cout << "This is CPP--int main()." << std::endl;
   ierr = whoami_();
   cpi_(&tol);
   std::cout << "The area of a disk r = " << r << " is " << diskarea_(&r) << std::endl;
   ierr = hi_();
   std::cout << std::endl;
   return 0;
}
