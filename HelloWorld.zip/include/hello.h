/**
 *       @file  hello.h
 *      @brief  
 *
 *   @internal
 *     Created  28/12/2020
 *     Company  liyu@tjufe.edu.cn
 *
 * =====================================================================================
 */
#ifndef  _HELLO_H_
#define  _HELLO_H_

#define F77name(name) name ## _

#ifdef __cplusplus
extern "C" {
#endif

   int hi_(void);
   int whoami_(void);
   void F77name(cpi)(double *tol);
   double F77name(diskarea)(double *r);

#ifdef __cplusplus
}
#endif



#endif   /* ----- end of hello.h ----- */
