/**
 *       @file  whoami.cpp
 *      @brief  
 *
 *   @internal
 *     Created  28/12/2020
 *     Company  liyu@tjufe.edu.cn
 *
 * =====================================================================================
 */
#include <iostream>
#include "hello.h"

   int
whoami_( void ) 
{
   std::cout << "This is CPP--int whoami_()." << std::endl;
   std::cout << "I am a template of IDE with MAKEFILE mixed FORTRAN, C and C++." << std::endl;
   return 0;
}
