clear
tic
fun=@(x)(1/(2*pi)^2*exp( -0.5*(x(1).^2+x(2).^2+x(3).^2+x(4).^2) ));
xlim=[-8,+8;-8,+8;-8,+8;-8,+8];
number=10000000;
x=rand(4, number); x=16*x-8;
y=zeros(number, 1);
for i=1:number
	y(i)=fun(x(:, i))*16^4;
end
integral=mean(y);
toc
% doc parfor
% doc rand(m, n, 'gpuArray')
% doc gather
%%
clear
tic
fun=@(x)(1/(2*pi)^2*exp( -0.5*(x(1).^2+x(2).^2+x(3).^2+x(4).^2) ));
xlim=[-8,+8;-8,+8;-8,+8;-8,+8];
number=10000000;
x=rand(4, number); x=16*x-8;
y=zeros(number, 1);
parfor i=1:number
	y(i)=fun(x(:, i));
end
integral=mean(y)*16^4;
toc
%%
clear
tic
fun=@(x)(1/(2*pi)^2*exp( -0.5*(x(1).^2+x(2).^2+x(3).^2+x(4).^2) ));
xlim=[-8,+8;-8,+8;-8,+8;-8,+8];
number=10000000;
x1=rand(number, 1); x1=16*x1-8;
x2=rand(number, 1); x2=16*x2-8;
x3=rand(number, 1); x3=16*x3-8;
x4=rand(number, 1); x4=16*x4-8;
myfun=@(x1,x2,x3,x4)(1/(2*pi)^2*exp( -0.5*(x1.^2+x2.^2+x3.^2+x4.^2) ));
y=myfun(x1, x2, x3, x4);
integral=mean(y)*16^4;
toc
%%
clear
tic
fun=@(x)(1/(2*pi)^2*exp( -0.5*(x(1).^2+x(2).^2+x(3).^2+x(4).^2) ));
xlim=[-8,+8;-8,+8;-8,+8;-8,+8];
number=10000000;
x1=rand(number, 1, 'gpuArray'); x1=16*x1-8;
x2=rand(number, 1, 'gpuArray'); x2=16*x2-8;
x3=rand(number, 1, 'gpuArray'); x3=16*x3-8;
x4=rand(number, 1, 'gpuArray'); x4=16*x4-8;
myfun=@(x1,x2,x3,x4)(1/(2*pi)^2*exp( -0.5*(x1.^2+x2.^2+x3.^2+x4.^2) ));
y=myfun(x1, x2, x3, x4);
integral=mean(y)*16^4;
toc
