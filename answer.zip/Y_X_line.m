clear
Y=[
 2.307  19.952   8.740  13.840  7.487  32.757   8.953   9.293   5.960  14.820   1.492  16.715  19.291;...
 3.758  31.601  17.513  20.365 12.460  51.829  12.499  12.582   9.170  22.913   1.996  24.118  29.244;...
 6.770  53.755  32.144  37.569 20.631  74.973  18.591  19.609  17.492  33.259   3.341  34.370  49.083;...
15.980  92.696  56.359  67.670 33.744 158.786  38.048  37.869  33.167  71.770   6.953  75.219  83.054;...
39.139 174.401 105.410 130.561 62.196 329.898  80.087  79.805  65.657 150.633  17.927 169.083 150.091];
X=[50, 100, 200, 400, 800];
% doc figure
% doc hold on
% doc hold off
% doc plot
% doc legend 
% doc xlabel
% doc ylabel
% doc axis
% doc sort
% doc polyfit
% doc polyval
%%
color=[0 0 0;0 0 1;0 1 0;0 1 1;1 0 0;1 0 1;0 0 0;0 0 1;0 1 0;0 1 1;1 0 0;1 0 1;0 0 0];
shape={'o'  , '+' , '*' , 'x' , 'p' , 'h' , '+' , '*' , 'x' , 'p' , 'h' , 'o' , '*' };
name ={'Y_1','Y_2','Y_3','Y_4','Y_5','Y_6','Y_7','Y_8','Y_9','Y_{10}','Y_{11}','Y_{12}','Y_{13}'};
[a,b]=sort(Y(end,:),'descend');
figure
hold on
for i=1:13
fig(i)=plot(X,Y(:,b(i)),shape{i},'color',color(i,:));
t=polyfit(X,Y(:,b(i)),1);
plot(X,polyval(t,X),'-','color',color(i,:))
end
hold off
axis([0,850,0,350])
xlabel('X')
ylabel('Y')
legend(fig,name(b),'location','northeastoutside')
box on
grid on
grid minor
saveas(gca,'Y_X_line','jpeg') %'epsc'
%%
