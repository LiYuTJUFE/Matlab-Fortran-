/**
 *    @file  basic.c
 *   @brief  
 *
 *  @author  Yu Li, liyu@tjufe.edu.cn
 *
 *       Created:  2021/6/18
 *      Revision:  none
 */

#include	<stdio.h>
#include	<stdlib.h>

void printmatrix_(double **matrix, int *num);
int main()
{
	double matrix[3][3] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
	int number = 3;
	printmatrix_((double**)matrix, &number);
	return 0;
}

