clear
myfunc2=@(x, y, z)((x-y.*z).^2);
y=[3, 2; 1, 0]; z=[.2, .4; .6, .8];
[x,fval] = test_function(myfunc2,y,z);
x-y.*z
%%
clear
bnd=-10:0.001:10; n = length(bnd)-1;
x = zeros(n, 1); fval = zeros(n, 1);
fun=@(x)(sin(10*x).*exp(-0.1*x.^2));
options=optimset('TolX',1e-12);
tic
%for i=1:n
parfor i=1:n
[x(i),fval(i)] = fminbnd(fun,bnd(i),bnd(i+1),options);
end
toc
[~,i] = min(fval);
plot(x(i),fval(i),'o')
hold on
fplot(fun, [-10, 10])
hold off
%%
clear
fun=@(x)(sin(10*x).*exp(-0.1*x.^2));
x0 = 3;
options=optimoptions('fsolve','UseParallel',true);
tic
[x,fval] = fsolve(fun, x0, options);
toc
plot(x, fval, '*')
hold on
fplot(fun, [-10, 10])
hold off
%%
clear
gpuDevice
gpuDevice(1)
nrows=7000;
A=rand(nrows,nrows)+rand(nrows,nrows)*1i; 
B=rand(nrows,nrows)+rand(nrows,nrows)*1i;
tic
A=fft2(A); B=fft2(B); C=ifft2(A.*B);
toc
gpu_A=gpuArray(A); gpu_B=gpuArray(B);
tic
gpu_A=fft2(gpu_A); gpu_B=fft2(gpu_B); gpu_C=ifft2(gpu_A.*gpu_B);
toc
C=gather(gpu_C);
whos
