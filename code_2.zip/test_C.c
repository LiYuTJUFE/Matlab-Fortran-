#include	<stdio.h>
#include	<math.h>
#include	<time.h>

#include	"mex.h"
#include	"matrix.h"

void C_function(double *A, double *B, double *C, int nrows, int ncols);

void mexFunction(int nlhs,mxArray *plhs[],int nrhs,const mxArray *prhs[])
{
	clock_t start, finish;
	double duration;
	printf("This is C--void mexFunction for matlab\n");
	start = clock();
	/* Input */
	mwSize nrows, ncols;
	if (0==nrhs) {
		printf("Please Input nrows and ncols\n");
		return;
	}
	else if (1==nrhs) {
		nrows = (mwSize)mxGetScalar(prhs[0]);
		ncols = nrows;
	}
	else {
		nrows = (mwSize)mxGetScalar(prhs[0]);
		ncols = (mwSize)mxGetScalar(prhs[1]);
	}
	/* Output */
	plhs[0] = mxCreateDoubleMatrix(nrows, ncols, mxREAL);
	plhs[1] = mxCreateDoubleMatrix(nrows, ncols, mxREAL);
	plhs[2] = mxCreateDoubleMatrix(nrows, ncols, mxREAL);
	mxDouble *A = mxGetPr(plhs[0]);
	mxDouble *B = mxGetPr(plhs[1]);
	mxDouble *C = mxGetPr(plhs[2]);
	C_function((double*)A, (double*)B, (double*)C, (int)nrows, (int)ncols);
	finish = clock();  
	duration = (double)(finish-start)/CLOCKS_PER_SEC;  
	printf("%f seconds\n", duration);
	return;
}

void C_function(double *A, double *B, double *C, int nrows, int ncols)
{
	int row, col, idx;
	for(col = 0; col < ncols; ++col) {
		for(row = 0; row < nrows; ++row) {
			idx = row+col*nrows;
			if ((row+col+2) <= (nrows+ncols)/2) {
				A[idx] = sin(row+1)*cos(col+1);
				//A[idx] = (row+1)*10+col+1;
			}
			else {
				B[idx] = log(row+1)*tan(1.0/(col+1));
				//B[idx] = (row+1)*10+col+1;
			}
			C[idx] = A[idx]*B[idx];
		}
	}
	return;
}
