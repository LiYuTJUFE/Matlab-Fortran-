clear
tic
nrows=700; ncols=700;
for row=1:nrows
	for col=1:ncols
		if (row+col) <= (nrows+ncols)/2
			A(row,col) = sin(row)*cos(col);
		else 
			B(row,col) = log(row)*tan(1/col);
		end
		%C(row,col) = A(row,col)*B(row,col);
	end
end
toc
%%
clear
tic
nrows=7000; ncols=7000;
A = zeros(nrows, ncols); B = zeros(nrows, ncols);
C = zeros(nrows, ncols);
for row=1:nrows
	for col=1:ncols
		if (row+col) <= (nrows+ncols)/2
			A(row,col) = sin(row)*cos(col);
		else 
			B(row,col) = log(row)*tan(1/col);
		end
		C(row,col) = A(row,col)*B(row,col);
	end
end
toc
%%
clear
tic
nrows=7000; ncols=7000;
A = zeros(nrows, ncols); B = zeros(nrows, ncols);
C = zeros(nrows, ncols);
for col=1:ncols
	for row=1:nrows
		if (row+col) <= (nrows+ncols)/2
			A(row,col) = sin(row)*cos(col);
		else 
			B(row,col) = log(row)*tan(1/col);
		end
		C(row,col) = A(row,col)*B(row,col);
	end
end
toc
%%
clear
tic
nrows=7000; ncols=7000;
A = zeros(nrows, ncols); B = zeros(nrows, ncols);
x = linspace(1, nrows, nrows);
y = linspace(1, ncols, ncols);
[cols, rows] = meshgrid(y, x);
logic = (rows+cols) <= (nrows+ncols)/2;
idx_A = find(logic); idx_B = find(~logic);
A(idx_A) = sin(rows(idx_A)).*cos(cols(idx_A));
B(idx_B) = log(rows(idx_B)).*tan(1./cols(idx_B));
C = zeros(nrows, ncols);
C = A.*B;
toc
%%
clear
tic
nrows=7000; ncols=7000;
[A, B, C] = test_C(nrows, ncols);
toc
%%
clear
nrows = 7000; ncols = 7000;
%A = zeros(nrows, ncols, 'gpuArray'); 
%B = zeros(nrows, ncols, 'gpuArray');
cpu_A = zeros(nrows, ncols); cpu_B = zeros(nrows, ncols);
A = gpuArray(cpu_A); B = gpuArray(cpu_B);
tic
x = gpuArray.linspace(1,nrows,nrows);
y = gpuArray.linspace(1,ncols,ncols);
[cols,rows] = meshgrid(y,x);
%clear x y
logic = (rows+cols) <= (nrows+ncols)/2;
idx_A = find(logic); idx_B = find(~logic);
%clear logic
A(idx_A) = sin(rows(idx_A)).*cos(cols(idx_A));
B(idx_B) = log(rows(idx_B)).*tan(1./cols(idx_B));
C = zeros(nrows, ncols, 'gpuArray');
C = A.*B;
toc
cpu_A=gather(A); cpu_B=gather(B); cpu_C=gather(C);