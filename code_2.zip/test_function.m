function [x,fval] = test_function(myfunc2,y,z)
	n = length(y(:)); x = zeros(size(y)); fval = zeros(size(y));
	%for i = 1:n
	parfor i = 1:n
		myfunc1=@(x)(myfunc2(x, y(i), z(i)));
		[x(i),fval(i)]=fminbnd(myfunc1, -10, 10);
	end
end
