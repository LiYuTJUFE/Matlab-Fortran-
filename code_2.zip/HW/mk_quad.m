clear
tic
fun=@(x)(1/(2*pi)^2*exp( -0.5*(x(1).^2+x(2).^2+x(3).^2+x(4).^2) ));
xlim=[-8,+8;-8,+8;-8,+8;-8,+8];
number=10000000;
x=rand(4, number); x=16*x-8;
y=zeros(number, 1);
for i=1:number
	y(i)=fun(x(:, i))*16^4;
end
integral=mean(y);
toc
% doc parfor
% doc rand(m, n, 'gpuArray')
% doc gather
