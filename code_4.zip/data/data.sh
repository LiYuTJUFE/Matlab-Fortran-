i=1
for file in Andrews.petsc.bin.36.0223.093000 CO.petsc.bin.36.0223.092959 Ga10As10H30.petsc.bin.36.0223.092959 Ga19As19H42.petsc.bin.36.0223.092959 Ga3As3H12.petsc.bin.36.0223.092959 Ga41As41H72.petsc.bin.36.0223.092959 Ge87H76.petsc.bin.36.0223.092959 Ge99H100.petsc.bin.36.0223.092959 Si34H36.petsc.bin.36.0223.093000 Si41Ge41H72.petsc.bin.36.0223.093000 Si5H12.petsc.bin.36.0223.093000 Si87H76.petsc.bin.36.0223.093000 SiO2.petsc.bin.36.0223.093000
do
grep "^[0-9]" ${file} | awk -F' ' '{print $NF}' | tr "\n" " " > ${i}
echo "" >> ${i}
grep "^GCG"   ${file} | awk -F' ' '{print $4}'  | sed -r 's/\(//' | sed -r 's/\,//' | tr "\n" " " >> ${i}
echo "1e-12" >> ${i}
i=$[i+1]
done
