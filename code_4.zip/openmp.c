#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main(int argc,  char *argv[]){
   printf("%s\n", "======================================");
   int i, N = 32;
   if (argc >= 2) N = atoi(argv[1]);
   printf("The size fo array is %d\n", N);
   printf("%s\n", "======================================");
   float *a, *b, c;
   //在CPU上面分配内存
   a = (float*)malloc(N*sizeof(float));
   b = (float*)malloc(N*sizeof(float));
   //填充主机内存
   for(i = 0; i < N; i++){
      a[i] = 1.0; b[i] = -1.0;
   }
   c = 0.0;
#pragma omp parallel for num_threads(8) reduction(+:c)
   for(i = 0; i < N; i++){
      c += a[i]*b[i];
   }
   printf("c = %f \n", c);
   printf("%s\n", "======================================");
   //释放 CPU 上的内存
   free(a); free(b);
   return 0;
}
