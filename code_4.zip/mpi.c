/**
 *       @file  hw_MPI.c
 *      @brief  
 *
 *   @internal
 *     Created  28/12/2020
 *     Company  liyu@tjufe.edu.cn
 *
 * =====================================================================================
 */
#include	<stdio.h>
#include	<stdlib.h>
#include	<mpi.h>

#if USING_OMP
#ifndef OMP_NUM_THREADS
#define OMP_NUM_THREADS 4
#endif
#include	<omp.h>
#endif

int GetLocalRange(int *start,  int *end,  int nglobal)
{
   int nprocs, rank, nlocal, surplus;
   MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
   MPI_Comm_rank(MPI_COMM_WORLD, &rank);
   nlocal  = nglobal/nprocs;
   *start  = nlocal*rank;
   surplus = nglobal-nlocal*nprocs;
   if (rank < surplus) {
      nlocal++;
      *start += rank;
   }
   else {
      *start += surplus;
   }
   *end = *start+nlocal;
   return nlocal;
}

int main(int argc, char *argv[]) {
   int nprocs,rank;
   MPI_Init(&argc,&argv);
   MPI_Comm_size(MPI_COMM_WORLD,&nprocs);
   MPI_Comm_rank(MPI_COMM_WORLD,&rank);
   if (rank == 0) printf("%s\n", "======================================");
   printf ("[%d/%d] Hello World! For MPI, this is %d proc and num of procs %d\n",
	 rank,nprocs,rank,nprocs);
#if USING_OMP
   printf ("[%d/%d] Hello World! For OpenMP, this is %d thread and num of threads %d\n",
	 rank,nprocs,omp_get_thread_num(),omp_get_num_threads());
   printf ("The number of processors %d that are available to the program\n",omp_get_num_procs());
#endif
   if (rank == 0) printf("%s\n", "======================================");
   MPI_Barrier(MPI_COMM_WORLD);

   int i, N = 32;
   if (argc >= 2) N = atoi(argv[1]);
   printf("[%d/%d] The size fo array is %d\n", rank,nprocs,N);
   if (rank == 0) printf("%s\n", "======================================");
   int start, end, nlocal, nglobal = N;
   nlocal = GetLocalRange(&start,&end,nglobal);
   printf ("[%d/%d] nlocal = %d, nglobal = %d, start = %d, end = %d\n",
	 rank,nprocs,nlocal,nglobal,start,end);
   float *a, *b, c;
   //在CPU上面分配内存
   a = (float*)malloc(nlocal*sizeof(float));
   b = (float*)malloc(nlocal*sizeof(float));
   //填充主机内存
   for(i = 0; i < nlocal; i++){
      a[i] = 1.0; b[i] = -1.0;
   }
   MPI_Barrier(MPI_COMM_WORLD);
   if (rank == 0) printf("%s\n", "======================================");
   c = 0.0;
#if USING_OMP
#pragma omp parallel for num_threads(OMP_NUM_THREADS) reduction(+:c)
#endif
   for(i = 0; i < nlocal; i++){
      c += a[i]*b[i];
   }
   printf("[%d/%d] before Allreduce, c = %f\n", rank,nprocs,c);
   MPI_Barrier(MPI_COMM_WORLD);
   MPI_Allreduce(MPI_IN_PLACE,&c,1,MPI_FLOAT,MPI_SUM,MPI_COMM_WORLD);
   printf("[%d/%d] after  Allreduce, c = %f\n", rank,nprocs,c);
   if (rank == 0) printf("%s\n", "======================================");
   MPI_Finalize();
   return 0;
}
