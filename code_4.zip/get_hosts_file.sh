#!/usr/bin/bash
# liyu@tjufe.edu.cn
# the name of hosts file $1
# the number of request processes $2
# the number of processes at each node 
case "$#" in
   '0')
   echo "It should input the hosts file name and the number of request processes. For example,"
   echo "./get_hosts_file hosts_file 144"
   exit
   ;;
   '1')
   echo "It should input the hosts file name and the number of request processes. For example,"
   echo "./get_hosts_file hosts_file 144"
   exit
   ;;
   '2')
   ;;
esac


NPN=36
# exclude nodes
exclude_nodes="b01 b02"
# the number of processes
NP=0
touch $1
echo -n > $1
#echo "The file $1 includes the nodes as follows:"
for line in $(bhosts | awk '{if ($2=="ok" && $5=="0") print $1}')
do
	if [[ $exclude_nodes =~ $line ]]
	then
		echo "Exclude the node $line"
	else
		echo "Include the node $line"
		i=1
		while [ $i -le $NPN ]
		do
   			echo $line >> $1
			i=$[i+1]
		done
	fi
	NP=$[NP+NPN]
	if [[ $NP -ge $2 ]]
	then
		break
	fi
done
echo "The file $1 includes $(wc -l $1 | awk '{print $1}') processes."
