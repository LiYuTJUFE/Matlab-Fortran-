clear
A = rand(3);
B = rand(5);
C = rand(7);
matrix{1}=A;
matrix{2}=B;
matrix{3}=C;
for i=1:3
	[eigenvector{i}, eigenvalue{i}] = eig(matrix{i});
end
for i=1:3
	struct_data(i).matrix=matrix{i};
	struct_data(i).eigenvalue=diag(eigenvalue{i});
	struct_data(i).eigenvector=eigenvector{i};
end
save mat_eigenpair.mat struct_data
figure
hold on
for i=1:3
	plot(struct_data(i).eigenvalue,'o')
end
hold off
box on
%saveas(gca,'eigenvalue','epsc')
saveas(gca,'eigenvalue','jpeg')
%%
myfunc2=@(x, y, z)((x-y*z).^2);
coord=zeros(3,1);
for i = 1:3
	y = i; z = y.^0.5;
	myfunc1=@(x)(myfunc2(x, y, z));
	coord(i)=fminbnd(myfunc1, -10, 10);
end
save min_point.mat coord
whos
